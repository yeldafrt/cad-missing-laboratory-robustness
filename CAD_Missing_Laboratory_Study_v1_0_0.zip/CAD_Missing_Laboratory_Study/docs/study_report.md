# Robustness to Missing Laboratory Measurements in Coronary Artery Disease Prediction: The Effect of Training-Time Feature Masking

*Completed computational study | Reproducibility report | Version 1.0.0*

## 1. Research question and principal finding

This study tested whether exposing a classifier to missing measurements during training improves its predictions when blood-laboratory values are unavailable. Standard training was compared with training-time feature masking and with a model trained without laboratory variables. The primary model was logistic regression; random forest provided a secondary comparison.

> Primary Brier difference: +0.000785
> 95% conditional interval: [-0.001569, +0.003271]
> Masking minus standard training, all 14 laboratory values absent.

The primary analysis did not demonstrate an improvement from masking-based training. The interval includes both a small reduction and a small increase in Brier loss; this is not evidence of equivalence.

## 2. Source cohort

The UCI Z-Alizadeh Sani dataset contained 303 records, including 216 CAD labels and 87 Normal labels (71.3% CAD). Table 1 summarizes selected source-record characteristics. The outcome is the original Cath label, with Cad coded as 1 and Normal as 0. The repository defines CAD using at least 50% arterial diameter narrowing [1].

**Table 1. Selected cohort characteristics; counts unless otherwise stated.**

| Source label | Records | Mean age (SD) | Male | Diabetes | Hypertension |
| --- | --- | --- | --- | --- | --- |
| Normal | 87 | 53.1 (9.3) | 46 | 10 | 32 |
| CAD | 216 | 61.2 (9.9) | 130 | 80 | 147 |

All source records were retained. There were no missing source cells or exact duplicate rows. The workbook contained 55 predictor columns plus the outcome; removing the constant Exertional CP column left 54 predictors. Source documentation describes 54 features, but the reason for that discrepancy is unknown. Row-derived identifiers support reproducibility and do not independently verify clinical linkage.

## 3. Experimental methods

The blood-laboratory group consisted of FBS, CR, TG, LDL, HDL, BUN, ESR, HB, K, Na, WBC, Lymph, Neut, and PLT. The echocardiographic fields EF-TTE, Region RWMA, and VHD remained available, as did recorded histories such as DM and DLP. Removing current laboratory values therefore did not remove all related clinical information.

## Training and preprocessing

Standard training used the original 54 predictors. Masking training used three versions of each training record: complete inputs, all 14 laboratory columns missing, and 14 randomly selected predictor columns missing. Each version received weight one third. The no-laboratory model used the remaining 40 predictors. Numerical medians, numerical scaling, categorical modes, and one-hot encodings were learned only from original records in the relevant training partition. One missingness indicator was appended for every retained original predictor.

Logistic-regression C values were 0.1, 1, and 10. Random forests used 120 trees, no bootstrap sampling, square-root feature subsampling, minimum raw leaf size one, and minimum weighted leaf fractions of 0.01 or 0.03. Class weighting and outcome resampling were not applied. Missingness was introduced before imputation and encoding.

## Validation and missing-input conditions

Stratified 5-fold outer cross-validation was repeated 5 times. Three-fold inner validation selected hyperparameters using the equally weighted mean Brier loss on complete and all-laboratory-missing inputs. Strategies shared all partitions. Training variants were created after splitting. Table 2 specifies the test conditions; mask draws depended on fixed seeds and row identifiers, without outcome information.

**Table 2. Test conditions applied to the same held-out records.**

| Condition | Masking rule | Draws |
| --- | --- | --- |
| Complete inputs | No source value removed | 1 |
| Half laboratory group | 7 of 14 blood measurements per record | 5 |
| All laboratory values | All 14 blood measurements per record | 1 |
| Random 14 | 14 of 54 predictor columns per record | 5 |

Test masks were identical across strategies and repetitions. The matched random condition controlled the number of absent columns, not their information content. It could also remove nonlaboratory fields. The reduced model ignored masks affecting columns it did not use.

## Outcomes and uncertainty

The primary outcome was Brier(masking) minus Brier(standard) for logistic regression with all laboratory values absent. Negative differences favor masking. Brier loss and AUROC were computed separately for each repetition and mask draw, then averaged; prediction probabilities were not averaged first. Paired loss differences were averaged within source record and bootstrapped within outcome class 5,000 times. The 95% percentile intervals condition on fitted predictions and realized masks; they exclude model-refitting and fresh mask-generation uncertainty. Repeated splits do not increase the independent sample size.

The final protocol was recorded locally before fitting and was not externally preregistered. An implementation review before performance summaries replaced row-bootstrap forest settings with weighted-leaf, no-bootstrap settings; all reported models used the final configuration.

## 4. Numerical results

Table 3 reports mean performance with complete inputs and with all 14 laboratory measurements absent. LR denotes logistic regression; RF denotes random forest. Lower Brier scores indicate lower mean squared probability error. Higher AUROC indicates better discrimination.

**Table 3. Mean out-of-fold performance across five split assignments.**

| Model / strategy | Complete Brier | Complete AUROC | Labs absent Brier | Labs absent AUROC |
| --- | --- | --- | --- | --- |
| LR / Standard | 0.0971 | 0.9264 | 0.0947 | 0.9293 |
| LR / Masking | 0.0978 | 0.9252 | 0.0955 | 0.9274 |
| LR / No laboratory | 0.0941 | 0.9280 | 0.0941 | 0.9280 |
| RF / Standard | 0.1112 | 0.9183 | 0.1084 | 0.9113 |
| RF / Masking | 0.1099 | 0.9233 | 0.1056 | 0.9209 |
| RF / No laboratory | 0.1048 | 0.9200 | 0.1048 | 0.9200 |

For the primary missing-laboratory condition, standard logistic regression had Brier 0.0947 and AUROC 0.9293; masking training had Brier 0.0955 and AUROC 0.9274. The paired Brier difference was +0.000785, with 95% conditional interval [-0.001569, +0.003271]. The primary analysis did not demonstrate an improvement from masking-based training. The interval includes both a small reduction and a small increase in Brier loss; this is not evidence of equivalence.

## Reduced-feature reference and complete-input tradeoff

The logistic-regression model trained without laboratory predictors had Brier 0.0941 and AUROC 0.9280 in the primary condition. Its identical complete-input and laboratory-missing predictions are expected because laboratory columns are never supplied. With complete inputs, masking minus standard logistic-regression Brier loss was +0.000673, interval [-0.001773, +0.003323]. Thus, robustness comparisons must be accompanied by performance with complete inputs.

## Supporting analyses

For random forest under complete laboratory absence, masking minus standard Brier loss was -0.002750, interval [-0.005994, +0.000495]. The point estimate favored masking, while the interval included zero. This secondary result does not overturn the primary finding.

Random removal of 14 predictors produced a higher mean Brier loss than removal of the 14 laboratory predictors in all six model-strategy combinations. For standard logistic regression, random-14 Brier was 0.1284 and AUROC was 0.8698, compared with 0.0947 and 0.9293 under laboratory-group absence. This exploratory contrast shows sensitivity to which fields were masked within the dataset; it is not a causal measure of clinical test value.

Full precision estimates, repeat-specific results, paired contrasts, tuning scores, and record-level predictions accompany this report. Average precision and threshold-based balanced accuracy are supporting archived summaries. No secondary analysis was used to redefine the primary comparison.

## 5. Performance across missing-input conditions

Figure 1 displays both probability error and discrimination across all four conditions. It also shows the variability across the five split assignments.

![Figure 1](../figures/figure_1_performance.png)

Figure 1. Prediction performance under simulated missing measurements. Panels A and B show logistic-regression Brier score and AUROC; panels C and D show the corresponding random-forest results. Points are five-repeat means. Bars show the minimum and maximum across split assignments, not confidence intervals. Metrics for random masks are averaged across five draws within each repetition. The no-laboratory model remains unchanged by laboratory-only masking.

As shown in Figure 1, random removal of 14 predictors was more disruptive than removal of the 14 blood-laboratory columns under the tested conditions. The small changes for laboratory-only masking should be interpreted in the presence of retained symptoms, examination findings, histories, and echocardiography. They do not justify omitting laboratory tests in patient care.

## 6. Paired strategy comparisons

Figure 2 shows paired Brier-score differences for the primary condition, all 14 laboratory measurements absent. The first row is the prespecified primary comparison; the remaining rows are supporting contrasts.

![Figure 2](../figures/figure_2_paired_differences.png)

Figure 2. Paired Brier-score differences with complete laboratory absence. Negative values favor the first named strategy. Whiskers are 95% class-stratified paired bootstrap intervals, calculated from losses averaged within each source record over cross-validation repetitions. The dashed line marks no difference. These conditional intervals reuse archived predictions and do not include model-refitting uncertainty.

As shown in Figure 2, the primary point estimate was +0.000785. Its conditional interval crossed zero. Masking therefore did not show a demonstrated primary improvement over standard training in this cohort. The comparison with a model trained without laboratory values was also small, reinforcing the importance of retaining a reduced-feature reference.

A confidence interval containing zero does not establish equal performance. Neither an equivalence margin nor an equivalence test was specified. Supporting comparisons were not adjusted for multiplicity and should be interpreted descriptively.

## Interpretive boundary

The direction of a small performance difference can change across model families or test conditions. This experiment evaluates the specified fitted procedures, imputation rules, masks, and validation design. It does not establish a universal benefit or harm from training-time masking.

## 7. Descriptive calibration

Figure 3 examines logistic-regression probabilities in the first split assignment. It is a descriptive diagnostic of probability behavior, not a further model-selection step.

![Figure 3](../figures/figure_3_calibration.png)

Figure 3. Logistic-regression calibration in the first split assignment. Panel A uses complete inputs; panel B masks all 14 laboratory measurements. Curves group 303 out-of-fold predictions into six quantile bins. The diagonal represents agreement between mean predicted probability and observed CAD fraction. Curves are shown for all three strategies. No recalibration was applied.

As shown in Figure 3, the three strategy curves are close in this selected split assignment, with visible departures from the ideal diagonal. Binned curves depend on the realized cohort and binning. Visual proximity of curves does not demonstrate equivalent calibration, and this figure does not validate probabilities for a new population.

Brier score measures overall squared probability error; it is not a pure calibration statistic. It also depends on discrimination and outcome frequency. The current experiment does not isolate those components or estimate clinical utility.

## Relation to the primary outcome

The main strategy comparison uses all five cross-validation repetitions, rather than selecting the most favorable calibration plot. The complete archived predictions make alternative descriptive checks possible, but any additional checks should be labeled as subsequent exploratory analyses.

## 8. Interpretation and limitations

In the primary analysis, training-time feature masking did not demonstrate improved Brier performance for logistic regression when recorded laboratory measurements were withheld. A separate model trained without these variables was a competitive reference within this dataset. These findings are specific to the selected cohort and experiment; they do not imply that laboratory information lacks clinical value.

The source cohort is small and retrospective, with a high proportion of CAD labels. No independently collected external validation cohort or prospective evaluation was included. Exact duplicate-row screening cannot independently establish participant linkage, representativeness, or independence. Cross-validation repetitions and masked copies do not create additional participants.

The source does not establish that every predictor preceded knowledge of the angiographic label. Excluding Cath prevents direct inclusion of that column, but cannot guarantee temporal independence. Retained echocardiography, symptoms, examination findings, and histories limit interpretation of the laboratory-absence scenario.

Masks were controlled simulations rather than observations of actual test-ordering or missing-data mechanisms. Matching the number of missing columns does not match information content. Conditional bootstrap intervals exclude full training and mask-generation uncertainty. No conclusions about safe test omission, clinical benefit, cost savings, or deployment readiness follow from these analyses.

## 9. Reproduction and outputs

The final run archived 150 fitted model bundles and 109,080 prediction rows, representing repeated predictions of 303 source records. The package includes fixed partitions, test masks, tuning records, performance tables, model snapshots, code, and verification outputs. Python and library versions are recorded in validation/run_summary.json and requirements.txt. A separate full refit reproduced 150 models and 109,080 prediction rows with maximum probability difference 0.0e+00; selected hyperparameters were identical. This verifies computational reproducibility, not external validity.

```bash
python src/run_study.py --jobs 4
python src/summarize.py
python src/validate.py
python src/build_report.py
```

Use --output DIRECTORY for a separate fitting-output directory and --input DIRECTORY for subsequent summary, validation, and report scripts. Input source data and the original analysis configuration remain in the package. Numerical outputs may vary slightly across library versions or platforms. Serialized models should be loaded only from trusted sources.

## Reference and source attribution

[1] Alizadehsani R, Roshanzamir M, Sani Z. Z-Alizadeh Sani [Dataset]. UCI Machine Learning Repository; 2013. https://doi.org/10.24432/C5Q31T. Retrieved 2026-11-23. Dataset license: Creative Commons Attribution 4.0 International, https://creativecommons.org/licenses/by/4.0/. Source-record export and transformations are documented in data_provenance.md.
