# Data Provenance

## Source and attribution

Alizadehsani, R., Roshanzamir, M., and Sani, Z. (2013). *Z-Alizadeh Sani* [Dataset]. UCI Machine Learning Repository. DOI: https://doi.org/10.24432/C5Q31T.

Repository record: https://archive.ics.uci.edu/dataset/412/z+alizadeh+sani

Source archive: https://archive.ics.uci.edu/static/public/412/z%2Balizadeh%2Bsani.zip

Retrieved: 2026-11-23. The repository identifies the dataset license as Creative Commons Attribution 4.0 International: https://creativecommons.org/licenses/by/4.0/.

Source archive SHA-256:

```text
48210a6623fa6112423d9bc357f72fe3fca12ae77866e63e08632e15d95b724e
```

The archive contains `Z-Alizadeh sani dataset.xlsx`. Its first worksheet was read with pandas and exported to `data/source_data.csv`, retaining source row order, column names, categorical spellings, and numerical values. Spreadsheet formatting and workbook metadata are not included. CSV serialization does not preserve spreadsheet display formatting or binary identity.

Source CSV SHA-256:

```text
bc90f8dec1388e38a4d608d6015941c0460d0924541fee1c43279498d3a60c67
```

## Analytical transformations

The source CSV contains 303 rows and 56 columns. Repository prose describes 54 features, whereas the workbook contains 55 predictor columns plus `Cath`. Excluding the constant `Exertional CP` column yields 54 analyzed predictors. The reason for the documentation discrepancy is unknown.

`Cath = Cad` maps to outcome 1 and `Cath = Normal` to 0. The repository defines CAD using at least 50% arterial diameter narrowing. No records are removed. Original coding, including `Fmale`, is preserved. `data/analysis_records.csv` adds `patient_id`, a sequential source-row identifier from 1 to 303. It is a reproducibility key, not an original clinical identifier or independently verified linkage key.

The dictionary records original data types, roles, groups, and missing counts. Grouping of the 14 blood measurements is an analytical specification. Simulated missing values exist only in experimental transformations, not in the bundled source CSV.
