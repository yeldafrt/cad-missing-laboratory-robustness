# Analysis Protocol

## Design and data

This retrospective computational experiment uses 303 records: 216 labeled `Cad` and 87 labeled `Normal`. The downloaded table contains 55 predictor columns and the `Cath` outcome. The constant `Exertional CP` column is excluded, leaving 54 predictors. `Cath` is never a predictor. There are no missing cells or exact duplicate rows in the source export. Settings were recorded locally before the final fitting run; this is not external preregistration. A pre-summary implementation review replaced row-bootstrap forest settings with no-bootstrap, weighted-leaf settings, as recorded in the configuration.

The primary missing group comprises 14 blood-laboratory columns: `FBS`, `CR`, `TG`, `LDL`, `HDL`, `BUN`, `ESR`, `HB`, `K`, `Na`, `WBC`, `Lymph`, `Neut`, and `PLT`. Echocardiographic columns `EF-TTE`, `Region RWMA`, and `VHD` remain available. Histories such as `DM` and `DLP` also remain available. Thus, the intervention removes recorded laboratory values, not every clinical fact related to those measurements.

## Models and training strategies

Logistic regression is the primary model; random forest is secondary. Three strategies are fitted:

1. **Standard:** Train on the original 54 predictors.
2. **Masking:** Create three versions of each training record: original inputs, all 14 laboratory columns missing, and 14 randomly chosen predictor columns missing. Each version receives weight one third.
3. **No laboratory:** Train on the 40 remaining predictors, excluding the laboratory group entirely.

All strategies use numerical median imputation and standardization, categorical modal imputation and one-hot encoding, plus one missingness indicator per retained original column. Preprocessing is fitted exclusively on original records in the relevant training partition, before creating training variants. Unknown categorical values are ignored by the encoder. Class weighting and outcome resampling are not used.

## Validation and tuning

Five repetitions of stratified five-fold outer cross-validation produce out-of-fold predictions for every record. Three-fold stratified inner cross-validation selects hyperparameters independently within each outer training partition. All strategies use identical partitions. Training variants are created only after splitting, so versions of an outer-test record never enter training.

Logistic-regression regularization values are `C = 0.1, 1, 10`. Random forests have 120 trees, no bootstrap sampling, and minimum weighted leaf fractions of 0.01 or 0.03. The minimum raw leaf size is one; weighted leaf constraints keep the training-weight scale comparable across strategies. The common tuning objective equally weights Brier loss on original and all-laboratory-missing inner-validation inputs. Ties follow grid order. Hyperparameters are not selected from outer-test results.

## Test conditions

- **Clean:** All analyzed source values remain available.
- **Laboratory half:** Seven of the 14 laboratory columns are masked per record, with five draws.
- **Laboratory all:** All 14 laboratory columns are masked.
- **Random 14:** Fourteen of the 54 original predictor columns are masked per record, with five draws.

Masks use fixed seeds and row identifiers, without outcome information. Identical test masks are used across strategies and repetitions. Random-14 masks can remove laboratory and nonlaboratory variables; the reduced model only receives the retained variables. Missingness is introduced before imputation and encoding.

## Outcomes and uncertainty

The primary estimand is Brier loss for masking minus standard logistic-regression training under complete laboratory absence. Secondary summaries include AUROC and complete-input performance, alongside the reduced-feature comparator. Lower Brier scores indicate lower mean squared probability error; higher AUROC indicates better ranking.

For paired Brier comparisons, losses are averaged within each record over mask draws and cross-validation repetitions. Class-stratified paired bootstrap resampling uses 5,000 draws. Intervals condition on archived predictions and exclude full model-refitting uncertainty. Repetitions and masked copies are not independent additional participants. Supporting comparisons are exploratory and do not support unqualified multiple-testing claims.
