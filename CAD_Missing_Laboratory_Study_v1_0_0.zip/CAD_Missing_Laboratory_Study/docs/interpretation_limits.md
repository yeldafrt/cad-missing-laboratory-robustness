# Interpretation Limits

This is a controlled missing-input experiment in one small retrospective dataset. It does not reproduce a known hospital's ordering policy, missingness mechanism, measurement error, or workflow. Results describe the specified masks and fitted models.

The 303 records and their available labels are the inferential units. Cross-validation repetitions and masked versions do not create additional independent participants. Exact row duplication was checked, but independently verified participant linkage and sampling independence are unavailable. Bootstrap intervals are conditional on fitted predictions and do not fully capture uncertainty from training, model selection, or generation of new missingness masks.

The source does not establish that every predictor was recorded before the angiographic outcome became known. Removing `Cath` prevents direct inclusion of that outcome, but cannot guarantee temporal independence or suitability for prospective triage. Retained echocardiography and clinical histories restrict interpretation of “laboratory unavailable.” The study does not simulate an absence of all diagnostic information.

Training-time masking can change performance with complete inputs; that tradeoff must accompany claims of robustness. The reduced-feature comparator tests whether fitting directly to available variables is sufficient. Its identical predictions for clean and laboratory-missing inputs are expected by construction.

Random masking matches the number of absent columns, not their clinical information content. It can hide categorical fields, correlated measurements, or variables absent from the reduced model. Results do not identify causal clinical importance or imply that any test can safely be omitted.

Random forests use no bootstrap sampling and constrain leaves by training-weight fraction, with equal total training weight per source record. This reduces differences caused solely by duplicated training versions. The comparison nevertheless evaluates the implemented masking procedure as a whole, not an isolated clinical mechanism.

No external validation cohort or prospective clinical evaluation is included. This package does not establish diagnostic safety, clinical benefit, cost savings, or readiness for patient care. A favorable result is not assumed, and exploratory comparisons should not be described as independent confirmatory discoveries.
