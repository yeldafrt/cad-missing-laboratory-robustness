"""Optional retrieval of the exact public source archive; not needed for reproduction."""
import argparse,hashlib,io,urllib.request,zipfile
from pathlib import Path
import pandas as pd
URL='https://archive.ics.uci.edu/static/public/412/z%2Balizadeh%2Bsani.zip'
EXPECTED='48210a6623fa6112423d9bc357f72fe3fca12ae77866e63e08632e15d95b724e'
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path('retrieved_source.csv'))
    args=ap.parse_args();data=urllib.request.urlopen(URL,timeout=60).read()
    if hashlib.sha256(data).hexdigest()!=EXPECTED:raise ValueError('Source archive changed; review before use.')
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        names=[n for n in z.namelist() if n.endswith('.xlsx')]
        if len(names)!=1:raise ValueError('Unexpected archive structure')
        frame=pd.read_excel(io.BytesIO(z.read(names[0])))
    args.output.parent.mkdir(parents=True,exist_ok=True);frame.to_csv(args.output,index=False)
    print(f'Exported {len(frame)} records to {args.output.name}')
