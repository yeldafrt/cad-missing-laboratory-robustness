"""Create a checksum manifest and a portable archive of this study package."""
from pathlib import Path
import argparse,csv,hashlib,zipfile

ROOT=Path(__file__).resolve().parents[1]

def package(root,output):
    files=sorted(p for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts
                 and p.name!='MANIFEST_SHA256.csv' and not p.name.startswith('.') and p.suffix!='.pyc')
    with (root/'MANIFEST_SHA256.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=['path','size_bytes','sha256']);writer.writeheader()
        for path in files:
            blob=path.read_bytes();writer.writerow({'path':path.relative_to(root).as_posix(),'size_bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()})
    files.append(root/'MANIFEST_SHA256.csv')
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sorted(files):
            name='CAD_Missing_Laboratory_Study/'+path.relative_to(root).as_posix()
            info=zipfile.ZipInfo(name,date_time=(2026,11,23,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o644<<16;z.writestr(info,path.read_bytes())
    print(f'Packaged {len(files)} files; archive size {output.stat().st_size} bytes')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=ROOT.parent/'CAD_Missing_Laboratory_Study_v1_0_0.zip')
    package(ROOT,ap.parse_args().output.resolve())
