"""Validate splits, masks, metrics, and every archived model prediction."""
from pathlib import Path
import argparse,hashlib,json
import numpy as np
import pandas as pd
import joblib
from run_study import ROOT,CFG,LAB,load_data,masked,predict


def validate(inp):
    checks=[]
    def check(name,condition):
        if not bool(condition):raise AssertionError(name)
        checks.append({'check':name,'status':'PASS'})
    raw,X,y,ids=load_data()
    p=pd.read_csv(inp/'results/predictions.csv.gz')
    folds=pd.read_csv(inp/'data/outer_folds.csv')
    inner=pd.read_csv(inp/'data/inner_folds.csv')
    chosen=pd.read_csv(inp/'results/selected_parameters.csv')
    tune=pd.read_csv(inp/'results/inner_tuning.csv')
    masks=pd.read_csv(inp/'data/test_masks.csv').fillna('')
    expected=len(ids)*CFG['outer_repeats']*len(CFG['models'])*len(CFG['strategies'])*(2+2*CFG['mask_draws'])
    check('Expected prediction row count',len(p)==expected)
    key=['patient_id','repeat','model','strategy','condition','mask_draw']
    check('Prediction keys unique',not p.duplicated(key).any())
    check('Probabilities finite and bounded',np.isfinite(p.probability).all() and p.probability.between(0,1).all())
    check('Outcome labels match source',np.array_equal(p.y.to_numpy(),y[p.patient_id.to_numpy()-1]))
    check('One outer test fold per record and repetition',len(folds)==len(ids)*CFG['outer_repeats'] and not folds.duplicated(['patient_id','repeat']).any())
    for (repeat,fold),g in folds.groupby(['repeat','fold']):
        it=inner[(inner.repeat==repeat)&(inner.outer_fold==fold)]
        check(f'Inner and outer separation r{repeat} f{fold}',not set(g.patient_id).intersection(it.patient_id) and len(it)==len(ids)-len(g) and it.patient_id.nunique()==len(it))
    for cond,n in [('clean',0),('laboratory_half',7),('laboratory_all',14),('random_14',14)]:
        check('Exact mask count '+cond,(masks.loc[masks.condition==cond,'missing_count']==n).all())
    for (cond,draw),g in masks.groupby(['condition','mask_draw']):
        frame=masked(X,ids,cond,int(draw))
        expected_cols=['|'.join(frame.columns[frame.iloc[i].isna()].tolist()) for i in range(len(ids))]
        check(f'Archived masks reproduced {cond} draw{draw}',g.sort_values('patient_id').missing_columns.tolist()==expected_cols)
    check('Target and constant field excluded',not {'Cath','Exertional CP','LAD','LCX','RCA'}.intersection(X.columns))
    check('Only laboratory field definitions removed',set(LAB).isdisjoint(CFG['retained_echo_columns']))
    # Full saved-model verification, without fitting.
    maxerr=0.;total=0;model_count=0
    for path in sorted((inp/'models').glob('*.joblib')):
        b=joblib.load(path);model_count+=1
        train=set(b['train_patient_ids']);test=set(b['test_patient_ids'])
        check('Disjoint model partition '+path.stem,not train.intersection(test) and len(train|test)==len(ids))
        expected_test=set(folds[(folds.repeat==b['repeat'])&(folds.fold==b['fold'])].patient_id)
        check('Model partition agrees with outer ledger '+path.stem,test==expected_test)
        check('Model columns exclude target '+path.stem,'Cath' not in b['columns'])
        if b['strategy']=='no_laboratory':check('Reduced model excludes labs '+path.stem,not set(LAB).intersection(b['columns']))
        if b['model_name']=='random_forest':
            check('Forest uses weight-based leaves '+path.stem,b['model'].bootstrap is False and b['model'].min_weight_fraction_leaf in CFG['forest_min_weight_fraction_leaf_grid'])
        sub=p[(p.repeat==b['repeat'])&(p.fold==b['fold'])&(p.model==b['model_name'])&(p.strategy==b['strategy'])]
        for (cond,draw),g in sub.groupby(['condition','mask_draw']):
            ix=g.patient_id.to_numpy()-1
            xx=masked(X.iloc[ix],g.patient_id.to_numpy(),cond,int(draw))
            prob=predict(b,xx)
            maxerr=max(maxerr,float(np.max(np.abs(prob-g.probability.to_numpy()))));total+=len(g)
    check('All expected models verified',model_count==CFG['outer_repeats']*CFG['outer_folds']*len(CFG['models'])*len(CFG['strategies']))
    check('Every archived prediction reproduced',total==len(p) and maxerr<1e-12)
    for _,z in chosen.iterrows():
        t=tune[(tune.repeat==z['repeat'])&(tune.outer_fold==z.outer_fold)&(tune.model==z.model)&(tune.strategy==z.strategy)]
        scores=t.groupby('parameter',sort=False).objective.mean()
        check(f'Inner selection {z.model} {z.strategy} r{z["repeat"]} f{z.outer_fold}',np.isclose(scores.loc[z.selected_parameter],scores.min(),atol=1e-14))
    nr=p[(p.strategy=='no_laboratory')&p.condition.isin(['clean','laboratory_half','laboratory_all'])]
    spread=nr.groupby(['patient_id','repeat','model']).probability.agg(lambda s:s.max()-s.min())
    check('Reduced-model laboratory invariance',spread.max()<1e-14)
    contrasts=pd.read_csv(inp/'results/paired_brier_contrasts.csv')
    a=contrasts[contrasts.primary]
    check('Exactly one prespecified primary contrast',len(a)==1 and a.iloc[0].model==CFG['primary_model'] and a.iloc[0].condition==CFG['primary_condition'])
    primary=p[(p.model==CFG['primary_model'])&(p.condition==CFG['primary_condition'])].copy()
    primary['loss']=(primary.probability-primary.y)**2
    loss=primary.groupby(['patient_id','strategy']).loss.mean().unstack()
    delta=float((loss['masking']-loss['standard']).mean())
    check('Primary effect independently recalculated',np.isclose(delta,a.iloc[0].delta_brier,atol=1e-14))
    saved=json.loads((inp/'validation/run_summary.json').read_text())
    check('Protocol hash matches fitting run',saved['protocol_sha256']==hashlib.sha256((ROOT/'config/protocol.json').read_bytes()).hexdigest())
    report={'status':'PASS','checks_passed':len(checks),'models_verified':model_count,'predictions_verified':total,
        'max_prediction_absolute_error':maxerr,'primary_delta_brier_recalculated':delta,'checks':checks}
    (inp/'validation/verification_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,default=ROOT)
    validate(ap.parse_args().input.resolve())
