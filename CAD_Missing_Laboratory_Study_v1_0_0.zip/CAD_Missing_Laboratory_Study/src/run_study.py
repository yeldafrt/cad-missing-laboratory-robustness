"""Run the complete nested cross-validation experiment from bundled source data."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import platform
import time
import warnings
import numpy as np
import pandas as pd
import joblib
from joblib import Parallel, delayed
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import brier_score_loss, roc_auc_score, average_precision_score, balanced_accuracy_score
import sklearn

ROOT = Path(__file__).resolve().parents[1]
CFG = json.loads((ROOT / 'config/protocol.json').read_text())
LAB = CFG['laboratory_columns']


def load_data():
    raw = pd.read_csv(ROOT / 'data/source_data.csv')
    assert raw.shape == (303, 56)
    assert not raw.isna().any().any()
    assert not raw.duplicated().any()
    assert set(raw.Cath) == {'Cad', 'Normal'}
    assert raw['Exertional CP'].nunique() == 1
    X = raw.drop(columns=['Cath'] + CFG['excluded_predictors'])
    assert len(X.columns) == 54 and len(LAB) == 14
    assert not set(['Cath', 'LAD', 'LCX', 'RCA']).intersection(X.columns)
    y = (raw.Cath == CFG['positive_label']).astype(int).to_numpy()
    ids = np.arange(1, len(raw) + 1)
    return raw, X, y, ids


def masked(X, ids, condition, draw=0, salt=0):
    """Mask original columns, reproducibly and without consulting outcomes."""
    out = X.copy()
    if condition == 'clean':
        return out
    for i, pid in enumerate(ids):
        if condition == 'laboratory_all':
            cols = LAB
        else:
            candidates = LAB if condition == 'laboratory_half' else list(X.columns)
            k = 7 if condition == 'laboratory_half' else 14
            tag = 11 if condition == 'laboratory_half' else 29
            rng = np.random.default_rng(np.random.SeedSequence([CFG['base_seed'], int(pid), int(draw), int(salt), tag]))
            cols = rng.choice(candidates, k, replace=False).tolist()
        for col in cols:
            out.iat[i, out.columns.get_loc(col)] = np.nan
    return out


def preprocessing(X):
    num = X.select_dtypes(include='number').columns.tolist()
    cat = [c for c in X if c not in num]
    return ColumnTransformer([
        ('numeric', Pipeline([('impute', SimpleImputer(strategy='median')), ('scale', StandardScaler())]), num),
        ('categorical', Pipeline([('impute', SimpleImputer(strategy='most_frequent')), ('encode', OneHotEncoder(handle_unknown='ignore', sparse_output=False))]), cat)
    ], sparse_threshold=0)


def matrix(preprocessor, frame):
    return np.hstack([preprocessor.transform(frame), frame.isna().to_numpy(dtype=float)])


def make_model(name, param, seed):
    if name == 'logistic_regression':
        return LogisticRegression(C=float(param), solver='lbfgs', max_iter=3000, random_state=seed)
    return RandomForestClassifier(n_estimators=CFG['forest_n_estimators'], min_samples_leaf=1, min_weight_fraction_leaf=float(param), bootstrap=False,
        max_features='sqrt', random_state=seed, n_jobs=1, class_weight=None)


def prepare_training(X, y, ids, strategy, salt):
    columns = [c for c in X if c not in LAB] if strategy == 'no_laboratory' else list(X.columns)
    base = X[columns]
    pre = preprocessing(base).fit(base)
    if strategy == 'masking':
        copies = [X, masked(X, ids, 'laboratory_all'), masked(X, ids, 'random_14', salt=salt)]
        arr = np.vstack([matrix(pre, z[columns]) for z in copies])
        target = np.tile(y, 3)
        weights = np.full(len(target), 1 / 3)
    else:
        arr = matrix(pre, base)
        target = y.copy()
        weights = np.ones(len(y))
    assert np.isclose(weights.sum(), len(y))
    return pre, columns, arr, target, weights


def predict(bundle, X):
    return bundle['model'].predict_proba(matrix(bundle['preprocessor'], X[bundle['columns']]))[:, 1]


def fold_job(repeat, fold, train, test, X, y, ids, output):
    seed = CFG['base_seed'] + repeat * 100 + fold
    Xtr, ytr, itr = X.iloc[train], y[train], ids[train]
    Xte, yte, ite = X.iloc[test], y[test], ids[test]
    assert not set(itr).intersection(ite)
    inner = list(StratifiedKFold(CFG['inner_folds'], shuffle=True, random_state=seed+10000).split(Xtr, ytr))
    rows, tuning, selections, fold_membership = [], [], [], []
    for infold, (a, b) in enumerate(inner):
        assert not set(itr[a]).intersection(itr[b])
        for pos in b:
            fold_membership.append({'repeat': repeat, 'outer_fold': fold, 'inner_validation_fold': infold,
                                    'patient_id': int(itr[pos])})
    tests = []
    for cond in CFG['test_conditions']:
        draws = CFG['mask_draws'] if cond in ('laboratory_half','random_14') else 1
        for draw in range(draws):
            tests.append((cond, draw, masked(Xte, ite, cond, draw)))
    for strategy in CFG['strategies']:
        inner_cache = []
        for infold, (a,b) in enumerate(inner):
            pre, cols, arr, target, weights = prepare_training(Xtr.iloc[a], ytr[a], itr[a], strategy, seed+infold)
            val = Xtr.iloc[b]
            inner_cache.append((arr,target,weights,
                matrix(pre,val[cols]), matrix(pre,masked(val,itr[b],'laboratory_all')[cols]), ytr[b]))
        pre, cols, arr, target, weights = prepare_training(Xtr, ytr, itr, strategy, seed+50000)
        for name in CFG['models']:
            grid = CFG['logistic_C_grid'] if name == 'logistic_regression' else CFG['forest_min_weight_fraction_leaf_grid']
            losses = []
            for param in grid:
                fold_losses = []
                for infold,(ia,iy,iw,vc,vl,vy) in enumerate(inner_cache):
                    m = make_model(name,param,seed+infold)
                    m.fit(ia,iy,sample_weight=iw)
                    lc = brier_score_loss(vy,m.predict_proba(vc)[:,1])
                    ll = brier_score_loss(vy,m.predict_proba(vl)[:,1])
                    score = (lc+ll)/2
                    fold_losses.append(score)
                    tuning.append({'repeat':repeat,'outer_fold':fold,'inner_fold':infold,'model':name,
                        'strategy':strategy,'parameter':param,'clean_brier':lc,'laboratory_all_brier':ll,'objective':score})
                losses.append(float(np.mean(fold_losses)))
            chosen = grid[int(np.argmin(losses))]
            fitted = make_model(name,chosen,seed)
            fitted.fit(arr,target,sample_weight=weights)
            bundle = {'model':fitted,'preprocessor':pre,'columns':cols,'strategy':strategy,
                      'model_name':name,'repeat':repeat,'fold':fold,'train_patient_ids':itr.tolist(),
                      'test_patient_ids':ite.tolist(),'selected_parameter':chosen}
            joblib.dump(bundle,output/'models'/f'r{repeat}_f{fold}_{name}_{strategy}.joblib',compress=3)
            selections.append({'repeat':repeat,'outer_fold':fold,'model':name,'strategy':strategy,
                               'selected_parameter':chosen,'inner_objective':min(losses),
                               'n_train':len(train),'n_test':len(test)})
            for cond,draw,xx in tests:
                probs=predict(bundle,xx)
                assert np.isfinite(probs).all() and ((probs>=0)&(probs<=1)).all()
                rows.extend({'patient_id':int(pid),'repeat':repeat,'fold':fold,'model':name,'strategy':strategy,
                    'condition':cond,'mask_draw':draw,'y':int(label),'probability':float(p)}
                    for pid,label,p in zip(ite,yte,probs))
    pd.DataFrame(rows).to_csv(output/'results'/f'predictions_r{repeat}_f{fold}.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    print(f'Completed repeat {repeat+1}/{CFG["outer_repeats"]}, fold {fold+1}/{CFG["outer_folds"]}',flush=True)
    return tuning,selections,fold_membership


def data_audit(raw,X,y,ids,output):
    raw.assign(patient_id=ids).to_csv(output/'data/analysis_records.csv',index=False)
    dictionary=[]
    for col in raw:
        if col=='Cath': group,role='outcome','target'
        elif col=='Exertional CP': group,role='clinical','excluded_constant'
        elif col in LAB: group,role='blood_laboratory','predictor'
        elif col in CFG['retained_echo_columns']: group,role='echocardiography','predictor'
        elif col in ['Q Wave','St Elevation','St Depression','Tinversion','LVH','Poor R Progression','BBB']: group,role='electrocardiography','predictor'
        else: group,role='demographic_history_examination','predictor'
        dictionary.append({'column':col,'group':group,'role':role,'data_type':str(raw[col].dtype),
            'unique_values':raw[col].nunique(),'missing_values':raw[col].isna().sum(),
            'coding':json.dumps(sorted(raw[col].unique().tolist()),ensure_ascii=True) if raw[col].nunique()<=12 else 'Original numerical values retained'})
    pd.DataFrame(dictionary).to_csv(output/'data/data_dictionary.csv',index=False)
    audit={'rows':len(raw),'source_columns':raw.shape[1],'source_predictors':raw.shape[1]-1,
        'analysis_predictors':X.shape[1],'laboratory_predictors':len(LAB),'reduced_predictors':X.shape[1]-len(LAB),
        'positive':int(y.sum()),'negative':int((1-y).sum()),'duplicate_rows':int(raw.duplicated().sum()),
        'missing_cells':int(raw.isna().sum().sum()),'constant_excluded':['Exertional CP'],
        'source_csv_sha256':hashlib.sha256((ROOT/'data/source_data.csv').read_bytes()).hexdigest(),
        'note':'Source documentation describes 54 features; downloaded workbook has 55 predictor columns. Removing the constant Exertional CP column yields 54 analyzed predictors. No claim is made about the cause of the documentation discrepancy.'}
    (output/'validation/data_audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    summary=[]
    for label in [0,1]:
        ix=y==label
        summary.append({'group':'CAD' if label else 'Normal','n':int(ix.sum()),
            'age_mean':float(raw.loc[ix,'Age'].mean()),'age_sd':float(raw.loc[ix,'Age'].std()),
            'male_n':int((raw.loc[ix,'Sex']=='Male').sum()),'diabetes_n':int(raw.loc[ix,'DM'].sum()),
            'hypertension_n':int(raw.loc[ix,'HTN'].sum())})
    pd.DataFrame(summary).to_csv(output/'results/cohort_summary.csv',index=False)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--jobs',type=int,default=4)
    ap.add_argument('--output',type=Path,default=ROOT)
    args=ap.parse_args();output=args.output.resolve()
    for folder in ['data','results','models','validation','figures']:(output/folder).mkdir(parents=True,exist_ok=True)
    started=time.time()
    raw,X,y,ids=load_data();data_audit(raw,X,y,ids,output)
    tasks=[];splits=[]
    for rep in range(CFG['outer_repeats']):
        cv=StratifiedKFold(CFG['outer_folds'],shuffle=True,random_state=CFG['base_seed']+rep)
        for fold,(train,test) in enumerate(cv.split(X,y)):
            tasks.append((rep,fold,train,test))
            splits.extend({'patient_id':int(ids[i]),'repeat':rep,'fold':fold,'y':int(y[i])} for i in test)
    pd.DataFrame(splits).to_csv(output/'data/outer_folds.csv',index=False)
    from joblib import parallel_config
    with parallel_config(backend='loky',inner_max_num_threads=1):
        res=Parallel(n_jobs=args.jobs)(delayed(fold_job)(r,f,a,b,X,y,ids,output) for r,f,a,b in tasks)
    pd.DataFrame([z for a,b,c in res for z in a]).to_csv(output/'results/inner_tuning.csv',index=False)
    pd.DataFrame([z for a,b,c in res for z in b]).to_csv(output/'results/selected_parameters.csv',index=False)
    pd.DataFrame([z for a,b,c in res for z in c]).to_csv(output/'data/inner_folds.csv',index=False)
    pred=pd.concat([pd.read_csv(output/'results'/f'predictions_r{r}_f{f}.csv.gz') for r,f,_,_ in tasks],ignore_index=True)
    pred.sort_values(['model','strategy','condition','repeat','patient_id','mask_draw']).to_csv(output/'results/predictions.csv.gz',index=False,compression={'method':'gzip','mtime':0})
    for r,f,_,_ in tasks:(output/'results'/f'predictions_r{r}_f{f}.csv.gz').unlink()
    runtime={'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,
        'scikit_learn':sklearn.__version__,'joblib':joblib.__version__,'elapsed_seconds':round(time.time()-started,2),
        'model_count':len(list((output/'models').glob('*.joblib'))),'prediction_rows':len(pred),
        'protocol_sha256':hashlib.sha256((ROOT/'config/protocol.json').read_bytes()).hexdigest()}
    (output/'validation/run_summary.json').write_text(json.dumps(runtime,indent=2)+'\n')
    print(json.dumps(runtime,indent=2),flush=True)

if __name__=='__main__':
    main()
