"""Build the English study report from archived numerical results and figures."""
from pathlib import Path
import argparse
import json
from html import escape
import pandas as pd
from PIL import Image as PILImage
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from matplotlib import font_manager
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether

ROOT = Path(__file__).resolve().parents[1]
MODEL_NAMES = {'logistic_regression': 'Logistic regression', 'random_forest': 'Random forest'}
STRATEGY_NAMES = {'standard': 'Standard', 'masking': 'Masking', 'no_laboratory': 'No laboratory'}


def fmt(value, decimals=4):
    return f'{float(value):.{decimals}f}'


def signed(value, decimals=6):
    return f'{float(value):+.{decimals}f}'


def markdown_table(rows):
    return '\n'.join(['| ' + ' | '.join(map(str, rows[0])) + ' |',
                     '| ' + ' | '.join(['---'] * len(rows[0])) + ' |'] +
                     ['| ' + ' | '.join(map(str, row)) + ' |' for row in rows[1:]])


def make_report(inp):
    cfg_path = inp/'config/protocol.json'
    if not cfg_path.exists():
        cfg_path = ROOT/'config/protocol.json'
    cfg = json.loads(cfg_path.read_text())
    summary = json.loads((inp/'results/analysis_summary.json').read_text())
    audit = json.loads((inp/'validation/data_audit.json').read_text())
    run = json.loads((inp/'validation/run_summary.json').read_text())
    reproduction_path = inp/'validation/reproduction_report.json'
    reproduction = json.loads(reproduction_path.read_text()) if reproduction_path.exists() else None
    perf = pd.read_csv(inp/'results/performance_summary.csv')
    contrasts = pd.read_csv(inp/'results/paired_brier_contrasts.csv')
    cohort = pd.read_csv(inp/'results/cohort_summary.csv')
    primary = summary['primary_result']
    title = cfg['study_title']
    dst = inp/'docs'; dst.mkdir(parents=True, exist_ok=True)

    def result(model, strategy, condition):
        return perf[(perf.model==model)&(perf.strategy==strategy)&(perf.condition==condition)].iloc[0]

    def contrast(model, condition, label):
        return contrasts[(contrasts.model==model)&(contrasts.condition==condition)&(contrasts.contrast==label)].iloc[0]

    standard = result('logistic_regression','standard','laboratory_all')
    masking = result('logistic_regression','masking','laboratory_all')
    reduced = result('logistic_regression','no_laboratory','laboratory_all')
    rf = contrast('random_forest','laboratory_all','masking minus standard')
    clean = contrast('logistic_regression','clean','masking minus standard')
    rand = result('logistic_regression','standard','random_14')
    if primary['ci_lower'] <= 0 <= primary['ci_upper']:
        primary_statement = ('The primary analysis did not demonstrate an improvement from masking-based training. '
            'The interval includes both a small reduction and a small increase in Brier loss; this is not evidence of equivalence.')
    elif primary['ci_upper'] < 0:
        primary_statement = ('The primary conditional interval favored masking-based training in this experiment. '
            'This result remains conditional on the fitted models and does not establish clinical benefit.')
    else:
        primary_statement = ('The primary conditional interval favored standard training in this experiment. '
            'This result remains conditional on the fitted models and does not establish clinical benefit.')

    cohort_rows = [['Source label', 'Records', 'Mean age (SD)', 'Male', 'Diabetes', 'Hypertension']]
    for label in ['Normal','CAD']:
        r=cohort[cohort.group==label].iloc[0]
        cohort_rows.append([label,str(int(r.n)),f'{r.age_mean:.1f} ({r.age_sd:.1f})',str(int(r.male_n)),str(int(r.diabetes_n)),str(int(r.hypertension_n))])
    performance_rows = [['Model / strategy','Complete\nBrier','Complete\nAUROC','Labs absent\nBrier','Labs absent\nAUROC']]
    for model in cfg['models']:
        for strategy in cfg['strategies']:
            a=result(model,strategy,'clean');b=result(model,strategy,'laboratory_all')
            short='LR' if model=='logistic_regression' else 'RF'
            performance_rows.append([short+' / '+STRATEGY_NAMES[strategy],fmt(a.brier_mean),fmt(a.auroc_mean),fmt(b.brier_mean),fmt(b.auroc_mean)])
    condition_rows=[['Condition','Masking rule','Draws'],
        ['Complete inputs','No source value removed','1'],
        ['Half laboratory group','7 of 14 blood measurements per record',str(cfg['mask_draws'])],
        ['All laboratory values','All 14 blood measurements per record','1'],
        ['Random 14','14 of 54 predictor columns per record',str(cfg['mask_draws'])]]

    reproduction_text = ''
    if reproduction and reproduction.get('status') == 'PASS':
        reproduction_text = (f" A separate full refit reproduced {reproduction['full_refit_models']} models and "
            f"{reproduction['compared_prediction_rows']:,} prediction rows with maximum probability difference "
            f"{reproduction['max_probability_absolute_difference']:.1e}; selected hyperparameters were identical. "
            'This verifies computational reproducibility, not external validity.')

    pages=[]
    def page(*blocks):pages.append(list(blocks))
    def p(text):return ('p',text)
    def h(text):return ('h',text)
    def t(caption,rows,widths=None):return ('table',caption,rows,widths)
    def figure(name,caption):return ('figure',name,caption)

    page(
        ('title',title),
        ('subtitle','Completed computational study | Reproducibility report | Version '+cfg['version']),
        h('1. Research question and principal finding'),
        p('This study tested whether exposing a classifier to missing measurements during training improves its predictions when blood-laboratory values are unavailable. Standard training was compared with training-time feature masking and with a model trained without laboratory variables. The primary model was logistic regression; random forest provided a secondary comparison.'),
        ('callout',f"Primary Brier difference: {signed(primary['delta_brier'])}\n95% conditional interval: [{signed(primary['ci_lower'])}, {signed(primary['ci_upper'])}]\nMasking minus standard training, all 14 laboratory values absent."),
        p(primary_statement),
        h('2. Source cohort'),
        p(f"The UCI Z-Alizadeh Sani dataset contained {audit['rows']} records, including {audit['positive']} CAD labels and {audit['negative']} Normal labels ({100*audit['positive']/audit['rows']:.1f}% CAD). Table 1 summarizes selected source-record characteristics. The outcome is the original Cath label, with Cad coded as 1 and Normal as 0. The repository defines CAD using at least 50% arterial diameter narrowing [1]."),
        t('Table 1. Selected cohort characteristics; counts unless otherwise stated.',cohort_rows,[76,53,103,50,67,83]),
        p('All source records were retained. There were no missing source cells or exact duplicate rows. The workbook contained 55 predictor columns plus the outcome; removing the constant Exertional CP column left 54 predictors. Source documentation describes 54 features, but the reason for that discrepancy is unknown. Row-derived identifiers support reproducibility and do not independently verify clinical linkage.')
    )
    page(
        h('3. Experimental methods'),
        p('The blood-laboratory group consisted of FBS, CR, TG, LDL, HDL, BUN, ESR, HB, K, Na, WBC, Lymph, Neut, and PLT. The echocardiographic fields EF-TTE, Region RWMA, and VHD remained available, as did recorded histories such as DM and DLP. Removing current laboratory values therefore did not remove all related clinical information.'),
        h('Training and preprocessing'),
        p('Standard training used the original 54 predictors. Masking training used three versions of each training record: complete inputs, all 14 laboratory columns missing, and 14 randomly selected predictor columns missing. Each version received weight one third. The no-laboratory model used the remaining 40 predictors. Numerical medians, numerical scaling, categorical modes, and one-hot encodings were learned only from original records in the relevant training partition. One missingness indicator was appended for every retained original predictor.'),
        p('Logistic-regression C values were 0.1, 1, and 10. Random forests used 120 trees, no bootstrap sampling, square-root feature subsampling, minimum raw leaf size one, and minimum weighted leaf fractions of 0.01 or 0.03. Class weighting and outcome resampling were not applied. Missingness was introduced before imputation and encoding.'),
        h('Validation and missing-input conditions'),
        p(f"Stratified {cfg['outer_folds']}-fold outer cross-validation was repeated {cfg['outer_repeats']} times. Three-fold inner validation selected hyperparameters using the equally weighted mean Brier loss on complete and all-laboratory-missing inputs. Strategies shared all partitions. Training variants were created after splitting. Table 2 specifies the test conditions; mask draws depended on fixed seeds and row identifiers, without outcome information."),
        t('Table 2. Test conditions applied to the same held-out records.',condition_rows,[116,263,53]),
        p('Test masks were identical across strategies and repetitions. The matched random condition controlled the number of absent columns, not their information content. It could also remove nonlaboratory fields. The reduced model ignored masks affecting columns it did not use.'),
        h('Outcomes and uncertainty'),
        p('The primary outcome was Brier(masking) minus Brier(standard) for logistic regression with all laboratory values absent. Negative differences favor masking. Brier loss and AUROC were computed separately for each repetition and mask draw, then averaged; prediction probabilities were not averaged first. Paired loss differences were averaged within source record and bootstrapped within outcome class 5,000 times. The 95% percentile intervals condition on fitted predictions and realized masks; they exclude model-refitting and fresh mask-generation uncertainty. Repeated splits do not increase the independent sample size.'),
        p('The final protocol was recorded locally before fitting and was not externally preregistered. An implementation review before performance summaries replaced row-bootstrap forest settings with weighted-leaf, no-bootstrap settings; all reported models used the final configuration.')
    )
    page(
        h('4. Numerical results'),
        p('Table 3 reports mean performance with complete inputs and with all 14 laboratory measurements absent. LR denotes logistic regression; RF denotes random forest. Lower Brier scores indicate lower mean squared probability error. Higher AUROC indicates better discrimination.'),
        t('Table 3. Mean out-of-fold performance across five split assignments.',performance_rows,[160,68,68,68,68]),
        p(f"For the primary missing-laboratory condition, standard logistic regression had Brier {fmt(standard.brier_mean)} and AUROC {fmt(standard.auroc_mean)}; masking training had Brier {fmt(masking.brier_mean)} and AUROC {fmt(masking.auroc_mean)}. The paired Brier difference was {signed(primary['delta_brier'])}, with 95% conditional interval [{signed(primary['ci_lower'])}, {signed(primary['ci_upper'])}]. {primary_statement}"),
        h('Reduced-feature reference and complete-input tradeoff'),
        p(f"The logistic-regression model trained without laboratory predictors had Brier {fmt(reduced.brier_mean)} and AUROC {fmt(reduced.auroc_mean)} in the primary condition. Its identical complete-input and laboratory-missing predictions are expected because laboratory columns are never supplied. With complete inputs, masking minus standard logistic-regression Brier loss was {signed(clean.delta_brier)}, interval [{signed(clean.ci_lower)}, {signed(clean.ci_upper)}]. Thus, robustness comparisons must be accompanied by performance with complete inputs."),
        h('Supporting analyses'),
        p(f"For random forest under complete laboratory absence, masking minus standard Brier loss was {signed(rf.delta_brier)}, interval [{signed(rf.ci_lower)}, {signed(rf.ci_upper)}]. The point estimate favored masking, while the interval included zero. This secondary result does not overturn the primary finding."),
        p(f"Random removal of 14 predictors produced a higher mean Brier loss than removal of the 14 laboratory predictors in all six model-strategy combinations. For standard logistic regression, random-14 Brier was {fmt(rand.brier_mean)} and AUROC was {fmt(rand.auroc_mean)}, compared with {fmt(standard.brier_mean)} and {fmt(standard.auroc_mean)} under laboratory-group absence. This exploratory contrast shows sensitivity to which fields were masked within the dataset; it is not a causal measure of clinical test value."),
        p('Full precision estimates, repeat-specific results, paired contrasts, tuning scores, and record-level predictions accompany this report. Average precision and threshold-based balanced accuracy are supporting archived summaries. No secondary analysis was used to redefine the primary comparison.')
    )
    page(
        h('5. Performance across missing-input conditions'),
        p('Figure 1 displays both probability error and discrimination across all four conditions. It also shows the variability across the five split assignments.'),
        figure('figure_1_performance.png','Figure 1. Prediction performance under simulated missing measurements. Panels A and B show logistic-regression Brier score and AUROC; panels C and D show the corresponding random-forest results. Points are five-repeat means. Bars show the minimum and maximum across split assignments, not confidence intervals. Metrics for random masks are averaged across five draws within each repetition. The no-laboratory model remains unchanged by laboratory-only masking.'),
        p('As shown in Figure 1, random removal of 14 predictors was more disruptive than removal of the 14 blood-laboratory columns under the tested conditions. The small changes for laboratory-only masking should be interpreted in the presence of retained symptoms, examination findings, histories, and echocardiography. They do not justify omitting laboratory tests in patient care.')
    )
    page(
        h('6. Paired strategy comparisons'),
        p('Figure 2 shows paired Brier-score differences for the primary condition, all 14 laboratory measurements absent. The first row is the prespecified primary comparison; the remaining rows are supporting contrasts.'),
        figure('figure_2_paired_differences.png','Figure 2. Paired Brier-score differences with complete laboratory absence. Negative values favor the first named strategy. Whiskers are 95% class-stratified paired bootstrap intervals, calculated from losses averaged within each source record over cross-validation repetitions. The dashed line marks no difference. These conditional intervals reuse archived predictions and do not include model-refitting uncertainty.'),
        p(f"As shown in Figure 2, the primary point estimate was {signed(primary['delta_brier'])}. Its conditional interval crossed zero. Masking therefore did not show a demonstrated primary improvement over standard training in this cohort. The comparison with a model trained without laboratory values was also small, reinforcing the importance of retaining a reduced-feature reference."),
        p('A confidence interval containing zero does not establish equal performance. Neither an equivalence margin nor an equivalence test was specified. Supporting comparisons were not adjusted for multiplicity and should be interpreted descriptively.'),
        h('Interpretive boundary'),
        p('The direction of a small performance difference can change across model families or test conditions. This experiment evaluates the specified fitted procedures, imputation rules, masks, and validation design. It does not establish a universal benefit or harm from training-time masking.')
    )
    page(
        h('7. Descriptive calibration'),
        p('Figure 3 examines logistic-regression probabilities in the first split assignment. It is a descriptive diagnostic of probability behavior, not a further model-selection step.'),
        figure('figure_3_calibration.png','Figure 3. Logistic-regression calibration in the first split assignment. Panel A uses complete inputs; panel B masks all 14 laboratory measurements. Curves group 303 out-of-fold predictions into six quantile bins. The diagonal represents agreement between mean predicted probability and observed CAD fraction. Curves are shown for all three strategies. No recalibration was applied.'),
        p('As shown in Figure 3, the three strategy curves are close in this selected split assignment, with visible departures from the ideal diagonal. Binned curves depend on the realized cohort and binning. Visual proximity of curves does not demonstrate equivalent calibration, and this figure does not validate probabilities for a new population.'),
        p('Brier score measures overall squared probability error; it is not a pure calibration statistic. It also depends on discrimination and outcome frequency. The current experiment does not isolate those components or estimate clinical utility.'),
        h('Relation to the primary outcome'),
        p('The main strategy comparison uses all five cross-validation repetitions, rather than selecting the most favorable calibration plot. The complete archived predictions make alternative descriptive checks possible, but any additional checks should be labeled as subsequent exploratory analyses.')
    )
    page(
        h('8. Interpretation and limitations'),
        p('In the primary analysis, training-time feature masking did not demonstrate improved Brier performance for logistic regression when recorded laboratory measurements were withheld. A separate model trained without these variables was a competitive reference within this dataset. These findings are specific to the selected cohort and experiment; they do not imply that laboratory information lacks clinical value.'),
        p('The source cohort is small and retrospective, with a high proportion of CAD labels. No independently collected external validation cohort or prospective evaluation was included. Exact duplicate-row screening cannot independently establish participant linkage, representativeness, or independence. Cross-validation repetitions and masked copies do not create additional participants.'),
        p('The source does not establish that every predictor preceded knowledge of the angiographic label. Excluding Cath prevents direct inclusion of that column, but cannot guarantee temporal independence. Retained echocardiography, symptoms, examination findings, and histories limit interpretation of the laboratory-absence scenario.'),
        p('Masks were controlled simulations rather than observations of actual test-ordering or missing-data mechanisms. Matching the number of missing columns does not match information content. Conditional bootstrap intervals exclude full training and mask-generation uncertainty. No conclusions about safe test omission, clinical benefit, cost savings, or deployment readiness follow from these analyses.'),
        h('9. Reproduction and outputs'),
        p(f"The final run archived {run['model_count']} fitted model bundles and {run['prediction_rows']:,} prediction rows, representing repeated predictions of {audit['rows']} source records. The package includes fixed partitions, test masks, tuning records, performance tables, model snapshots, code, and verification outputs. Python and library versions are recorded in validation/run_summary.json and requirements.txt." + reproduction_text),
        ('code','python src/run_study.py --jobs 4\npython src/summarize.py\npython src/validate.py\npython src/build_report.py'),
        p('Use --output DIRECTORY for a separate fitting-output directory and --input DIRECTORY for subsequent summary, validation, and report scripts. Input source data and the original analysis configuration remain in the package. Numerical outputs may vary slightly across library versions or platforms. Serialized models should be loaded only from trusted sources.'),
        h('Reference and source attribution'),
        p('[1] Alizadehsani R, Roshanzamir M, Sani Z. Z-Alizadeh Sani [Dataset]. UCI Machine Learning Repository; 2013. https://doi.org/10.24432/C5Q31T. Retrieved 2026-11-23. Dataset license: Creative Commons Attribution 4.0 International, https://creativecommons.org/licenses/by/4.0/. Source-record export and transformations are documented in data_provenance.md.')
    )

    # Generate a text counterpart from the same content blocks.
    md=[]
    for blocks in pages:
        for block in blocks:
            kind=block[0]
            if kind=='title':md.append('# '+block[1])
            elif kind=='subtitle':md.append('*'+block[1]+'*')
            elif kind=='h':md.append('## '+block[1])
            elif kind=='p':md.append(block[1])
            elif kind=='callout':md.append('> '+'\n> '.join(block[1].splitlines()))
            elif kind=='table':md.extend(['**'+block[1]+'**',markdown_table([[str(c).replace('\n',' ') for c in row] for row in block[2]])])
            elif kind=='figure':md.extend([f'![{block[2].split(".")[0]}](../figures/{block[1]})',block[2]])
            elif kind=='code':md.append('```bash\n'+block[1]+'\n```')
    (dst/'study_report.md').write_text('\n\n'.join(md)+'\n',encoding='utf-8')

    font_paths = {
        'ReportSans': font_manager.findfont(font_manager.FontProperties(family='DejaVu Sans')),
        'ReportSansBold': font_manager.findfont(font_manager.FontProperties(family='DejaVu Sans', weight='bold')),
        'ReportMono': font_manager.findfont(font_manager.FontProperties(family='DejaVu Sans Mono'))
    }
    for font_name, font_path in font_paths.items():
        pdfmetrics.registerFont(TTFont(font_name, font_path))
    dark=colors.HexColor('#24364B');teal=colors.HexColor('#137F78');gray=colors.HexColor('#506075')
    style={
        'body':ParagraphStyle('Body',fontName='ReportSans',fontSize=9.3,leading=13.1,textColor=dark,spaceAfter=8),
        'heading':ParagraphStyle('Heading',fontName='ReportSansBold',fontSize=12.3,leading=16,textColor=dark,spaceBefore=7,spaceAfter=8),
        'title':ParagraphStyle('ReportTitle',fontName='ReportSansBold',fontSize=21,leading=26,textColor=dark,spaceAfter=14),
        'subtitle':ParagraphStyle('Subtitle',fontName='ReportSans',fontSize=9,leading=12,textColor=gray,spaceAfter=18),
        'caption':ParagraphStyle('Caption',fontName='ReportSans',fontSize=8.5,leading=11.7,textColor=gray,spaceAfter=12),
        'cell':ParagraphStyle('Cell',fontName='ReportSans',fontSize=8,leading=10.5,textColor=dark),
        'headcell':ParagraphStyle('HeadCell',fontName='ReportSansBold',fontSize=8,leading=10.5,textColor=colors.white),
        'callout':ParagraphStyle('Callout',fontName='ReportSansBold',fontSize=10,leading=15,textColor=teal),
        'code':ParagraphStyle('Code',fontName='ReportMono',fontSize=8.3,leading=11.6,textColor=dark,spaceAfter=10)
    }
    story=[]
    content_width=A4[0]-88
    def para(text,sty='body'):
        return Paragraph(escape(text).replace('\n','<br/>'),style[sty])
    for i,blocks in enumerate(pages):
        if i:story.append(PageBreak())
        for block in blocks:
            kind=block[0]
            if kind in ('title','subtitle'):story.append(para(block[1],kind))
            elif kind=='h':story.append(para(block[1],'heading'))
            elif kind=='p':story.append(para(block[1]))
            elif kind=='callout':
                tab=Table([[para(block[1],'callout')]],colWidths=[content_width])
                tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,-1),colors.HexColor('#EAF5F2')),('BOX',(0,0),(-1,-1),.5,colors.HexColor('#C4DFDA')),('LEFTPADDING',(0,0),(-1,-1),12),('RIGHTPADDING',(0,0),(-1,-1),12),('TOPPADDING',(0,0),(-1,-1),10),('BOTTOMPADDING',(0,0),(-1,-1),10)]))
                story.extend([tab,Spacer(1,12)])
            elif kind=='table':
                rows=block[2]; widths=block[3]
                widths=[v/sum(widths)*content_width for v in widths] if widths else None
                table=Table([[para(str(c),'headcell' if r==0 else 'cell') for c in row] for r,row in enumerate(rows)],colWidths=widths,repeatRows=1,hAlign='LEFT')
                table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),dark),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#F1F5F8'),colors.white]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,-1),(-1,-1),.5,colors.HexColor('#CCD5DE'))]))
                story.append(KeepTogether([para(block[1],'caption'),table,Spacer(1,12)]))
            elif kind=='figure':
                f=inp/'figures'/block[1]
                with PILImage.open(f) as im:w,h=im.size
                figure_width=content_width
                story.extend([Image(str(f),width=figure_width,height=figure_width*h/w),Spacer(1,10),para(block[2],'caption')])
            elif kind=='code':story.append(para(block[1],'code'))
    pdf=dst/'study_report.pdf'
    def footer(canvas,doc):
        canvas.saveState();canvas.setStrokeColor(colors.HexColor('#CCD5DE'));canvas.line(44,39,A4[0]-44,39)
        canvas.setFont('ReportSans',8);canvas.setFillColor(gray);canvas.drawString(44,26,'Missing laboratory measurements | Computational study')
        canvas.drawRightString(A4[0]-44,26,str(doc.page));canvas.restoreState()
    doc=SimpleDocTemplate(str(pdf),pagesize=A4,rightMargin=44,leftMargin=44,topMargin=38,bottomMargin=52,
        title=title,author='',creator='',subject='Controlled missing-input experiment in coronary artery disease prediction')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    # Preserve the document while explicitly removing identifying metadata fields.
    from pypdf import PdfReader,PdfWriter
    reader=PdfReader(str(pdf));writer=PdfWriter();writer.clone_document_from_reader(reader)
    writer.add_metadata({'/Author':'','/Creator':'','/Title':title,'/Subject':'Computational study report'})
    tmp=pdf.with_suffix('.temporary.pdf')
    with tmp.open('wb') as stream:writer.write(stream)
    tmp.replace(pdf)
    print(json.dumps({'report_pdf':str(pdf),'report_markdown':str(dst/'study_report.md'),'pages':len(reader.pages)},indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,default=ROOT)
    args=ap.parse_args();make_report(args.input.resolve())
