"""Check all delivered files against MANIFEST_SHA256.csv without modifying them."""
from pathlib import Path
import argparse,csv,hashlib,json

def main(root):
    checked=0;errors=[]
    with (root/'MANIFEST_SHA256.csv').open(newline='',encoding='utf-8') as f:
        for row in csv.DictReader(f):
            path=root/row['path']
            if not path.is_file():
                errors.append({'path':row['path'],'reason':'missing'});continue
            blob=path.read_bytes()
            if len(blob)!=int(row['size_bytes']) or hashlib.sha256(blob).hexdigest()!=row['sha256']:
                errors.append({'path':row['path'],'reason':'checksum or size mismatch'})
            checked+=1
    print(json.dumps({'status':'PASS' if not errors else 'FAIL','files_checked':checked,'errors':errors},indent=2))
    if errors:raise SystemExit(1)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    main(ap.parse_args().root.resolve())
