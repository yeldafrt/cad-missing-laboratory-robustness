"""Recalculate tables and figures from archived out-of-fold predictions."""
from pathlib import Path
import argparse,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import brier_score_loss,roc_auc_score,average_precision_score,balanced_accuracy_score
from sklearn.calibration import calibration_curve
from run_study import CFG,ROOT,load_data,masked

NAMES={'standard':'Standard training','masking':'Masking training','no_laboratory':'No-laboratory model'}
MODELS={'logistic_regression':'Logistic regression','random_forest':'Random forest'}
CONDITIONS={'clean':'Complete inputs','laboratory_half':'7 laboratory values missing','laboratory_all':'14 laboratory values missing','random_14':'14 random values missing'}
COLORS={'standard':'#2563A6','masking':'#158477','no_laboratory':'#B77827'}


def save_figure(fig,path):
    fig.savefig(path.with_suffix('.png'),dpi=220,bbox_inches='tight',facecolor='white',metadata={'Software':'Matplotlib'})
    fig.savefig(path.with_suffix('.pdf'),bbox_inches='tight',facecolor='white',metadata={'Author':'','Creator':'','Title':path.stem})
    plt.close(fig)


def summarize(inp):
    pred=pd.read_csv(inp/'results/predictions.csv.gz')
    pred['brier_loss']=(pred.probability-pred.y)**2
    records=[]
    key=['model','strategy','condition','repeat','mask_draw']
    for values,g in pred.groupby(key,sort=True):
        z=dict(zip(key,values)); y=g.y.to_numpy();p=g.probability.to_numpy()
        z.update(brier=float(np.mean((p-y)**2)),auroc=roc_auc_score(y,p),average_precision=average_precision_score(y,p),
                 balanced_accuracy=balanced_accuracy_score(y,p>=.5),n=len(g))
        records.append(z)
    bydraw=pd.DataFrame(records);bydraw.to_csv(inp/'results/metrics_by_repeat_and_mask.csv',index=False)
    metrics=['brier','auroc','average_precision','balanced_accuracy']
    byrepeat=bydraw.groupby(['model','strategy','condition','repeat'])[metrics].mean().reset_index()
    byrepeat.to_csv(inp/'results/metrics_by_repeat.csv',index=False)
    agg=byrepeat.groupby(['model','strategy','condition'])[metrics].agg(['mean','std','min','max'])
    agg.columns=['_'.join(v) for v in agg.columns];agg=agg.reset_index()
    agg.to_csv(inp/'results/performance_summary.csv',index=False)
    losses=pred.groupby(['patient_id','y','model','strategy','condition']).brier_loss.mean().reset_index()
    losses.to_csv(inp/'results/patient_mean_losses.csv',index=False)
    labels=pred[['patient_id','y']].drop_duplicates().sort_values('patient_id')
    rng=np.random.default_rng(CFG['base_seed']+80000)
    # Sample records within each class; use identical paired resamples for all contrasts.
    zero=np.where(labels.y.to_numpy()==0)[0];one=np.where(labels.y.to_numpy()==1)[0]
    boot=np.hstack([rng.choice(zero,(CFG['bootstrap_replicates'],len(zero)),replace=True),
                    rng.choice(one,(CFG['bootstrap_replicates'],len(one)),replace=True)])
    contrasts=[]
    for (model,cond),g in losses.groupby(['model','condition']):
        wide=g.pivot(index='patient_id',columns='strategy',values='brier_loss').sort_index()
        for a,b in [('masking','standard'),('masking','no_laboratory'),('no_laboratory','standard')]:
            d=(wide[a]-wide[b]).to_numpy();bs=d[boot].mean(axis=1);lo,hi=np.quantile(bs,[.025,.975])
            contrasts.append({'model':model,'condition':cond,'contrast':a+' minus '+b,
                'delta_brier':float(d.mean()),'ci_lower':float(lo),'ci_upper':float(hi),
                'n_records':len(d),'bootstrap_replicates':CFG['bootstrap_replicates'],
                'primary':model==CFG['primary_model'] and cond==CFG['primary_condition'] and a=='masking' and b=='standard'})
    contrasts=pd.DataFrame(contrasts);contrasts.to_csv(inp/'results/paired_brier_contrasts.csv',index=False)
    block_random=[]
    for (model,strategy),g in losses.groupby(['model','strategy']):
        wide=g.pivot(index='patient_id',columns='condition',values='brier_loss').sort_index()
        d=(wide.laboratory_all-wide.random_14).to_numpy();lo,hi=np.quantile(d[boot].mean(axis=1),[.025,.975])
        block_random.append({'model':model,'strategy':strategy,'contrast':'laboratory_all minus random_14',
            'delta_brier':d.mean(),'ci_lower':lo,'ci_upper':hi})
    pd.DataFrame(block_random).to_csv(inp/'results/block_vs_random.csv',index=False)
    primary=contrasts.loc[contrasts.primary].iloc[0].to_dict()
    summary={'primary_result':primary,'analysis_records':len(labels),'cross_validation_repeats':CFG['outer_repeats'],
        'uncertainty_note':'Intervals are conditional patient-bootstrap intervals of repeated cross-validated losses. They do not include model-refitting uncertainty or independent external validation.',
        'metrics_note':'Brier loss and AUROC are calculated separately for each mask draw and repetition, then averaged. Probabilities are not averaged before calculating these metrics.'}
    (inp/'results/analysis_summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    # Archive explicit test masks, identical across repeats and strategies.
    raw,X,y,ids=load_data();maskrows=[]
    for cond in CFG['test_conditions']:
        nd=CFG['mask_draws'] if cond in ['laboratory_half','random_14'] else 1
        for draw in range(nd):
            frame=masked(X,ids,cond,draw)
            for pos,pid in enumerate(ids):
                cols=frame.columns[frame.iloc[pos].isna()].tolist()
                maskrows.append({'patient_id':int(pid),'condition':cond,'mask_draw':draw,'missing_count':len(cols),'missing_columns':'|'.join(cols)})
    pd.DataFrame(maskrows).to_csv(inp/'data/test_masks.csv',index=False)
    make_figures(inp,agg,contrasts,pred)
    print(json.dumps(summary,indent=2))


def make_figures(inp,agg,contrasts,pred):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                         'axes.titleweight':'bold','axes.labelcolor':'#253447','text.color':'#253447','axes.edgecolor':'#B0B8C2'})
    fig,axes=plt.subplots(2,2,figsize=(12,9))
    conds=list(CONDITIONS)
    for row,model in enumerate(MODELS):
        for col,metric in enumerate(['brier','auroc']):
            ax=axes[row,col]
            for k,strategy in enumerate(NAMES):
                t=agg[(agg.model==model)&(agg.strategy==strategy)].set_index('condition').loc[conds]
                y=np.arange(4)+(k-1)*.18
                m=t[metric+'_mean'].to_numpy();lo=t[metric+'_min'].to_numpy();hi=t[metric+'_max'].to_numpy()
                ax.errorbar(m,y,xerr=np.array([m-lo,hi-m]),fmt='o',capsize=3,color=COLORS[strategy],label=NAMES[strategy],markersize=5)
            ax.set_yticks(np.arange(4),[CONDITIONS[c] for c in conds] if col==0 else ['']*4)
            ax.invert_yaxis();ax.grid(axis='x',alpha=.18)
            ax.set_title(f'{chr(65+row*2+col)}. {MODELS[model]}')
            ax.set_xlabel('Brier score (lower is better)' if metric=='brier' else 'AUROC (higher is better)')
    h,l=axes[0,0].get_legend_handles_labels();fig.legend(h,l,loc='lower center',ncol=3,bbox_to_anchor=(.5,.025),frameon=False)
    fig.suptitle('Prediction performance under simulated missing measurements',fontsize=15,y=.98)
    fig.text(.5,.005,'Points: mean over five split assignments. Bars: minimum to maximum across assignments; not confidence intervals.',ha='center',fontsize=9)
    fig.tight_layout(rect=[0,.065,1,.95]);save_figure(fig,inp/'figures/figure_1_performance')
    fig,ax=plt.subplots(figsize=(10,5.5));sel=contrasts[contrasts.condition=='laboratory_all'].copy()
    rows=[]
    for model in MODELS:
        for c in ['masking minus standard','masking minus no_laboratory','no_laboratory minus standard']:
            rows.append(sel[(sel.model==model)&(sel.contrast==c)].iloc[0])
    for i,z in enumerate(rows):
        color='#158477' if z['primary'] else '#5F718A'
        ax.errorbar(z.delta_brier,i,xerr=[[z.delta_brier-z.ci_lower],[z.ci_upper-z.delta_brier]],fmt='o',capsize=4,color=color,markersize=7 if z['primary'] else 5)
        ax.text(1.01,i,f'{z.delta_brier:+.4f} [{z.ci_lower:+.4f}, {z.ci_upper:+.4f}]',transform=ax.get_yaxis_transform(),va='center',fontsize=9)
    labels=[]
    for z in rows:
        a,b=z.contrast.split(' minus ')
        labels.append(MODELS[z.model]+'\n'+NAMES[a]+' minus '+NAMES[b]+(' (primary)' if z['primary'] else ''))
    ax.set_yticks(range(len(rows)),labels);ax.invert_yaxis();ax.axvline(0,color='#888888',linestyle='--',linewidth=1)
    ax.grid(axis='x',alpha=.18);ax.set_xlabel('Paired Brier-score difference (negative favors the first strategy)')
    ax.set_title('All 14 laboratory measurements absent')
    fig.text(.5,.015,'95% class-stratified patient-bootstrap intervals, conditional on archived predictions; no refitting.',ha='center',fontsize=9)
    fig.subplots_adjust(left=.32,right=.71,bottom=.15,top=.9)
    save_figure(fig,inp/'figures/figure_2_paired_differences')
    fig,axes=plt.subplots(1,2,figsize=(10,4.7));cal=[]
    for j,cond in enumerate(['clean','laboratory_all']):
        ax=axes[j];ax.plot([0,1],[0,1],'--',color='#939CA8',lw=1)
        for strategy in NAMES:
            g=pred[(pred.model=='logistic_regression')&(pred.strategy==strategy)&(pred.condition==cond)&(pred.repeat==0)]
            observed,estimated=calibration_curve(g.y,g.probability,n_bins=6,strategy='quantile')
            ax.plot(estimated,observed,'o-',color=COLORS[strategy],label=NAMES[strategy],markersize=4)
            cal.extend({'condition':cond,'strategy':strategy,'bin':i,'mean_prediction':a,'observed_fraction':b} for i,(a,b) in enumerate(zip(estimated,observed)))
        ax.set(xlim=(0,1),ylim=(0,1),xlabel='Mean predicted probability',ylabel='Observed CAD fraction')
        ax.set_title(f'{chr(65+j)}. {CONDITIONS[cond]}');ax.grid(alpha=.15)
    h,l=axes[0].get_legend_handles_labels();fig.legend(h,l,loc='lower center',ncol=3,bbox_to_anchor=(.5,.03),frameon=False)
    fig.suptitle('Logistic-regression calibration: first split assignment',fontsize=13)
    fig.text(.5,.005,'Six quantile bins; descriptive illustration from 303 out-of-fold predictions. No recalibration applied.',ha='center',fontsize=9)
    fig.tight_layout(rect=[0,.1,1,.94]);save_figure(fig,inp/'figures/figure_3_calibration')
    pd.DataFrame(cal).to_csv(inp/'results/calibration_plot_data.csv',index=False)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,default=ROOT)
    args=ap.parse_args();summarize(args.input.resolve())
