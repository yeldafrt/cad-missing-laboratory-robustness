@echo off
setlocal
cd /d "%~dp0"
python src\run_study.py --jobs 4
if errorlevel 1 exit /b 1
python src\summarize.py
if errorlevel 1 exit /b 1
python src\validate.py
if errorlevel 1 exit /b 1
python src\build_report.py
if errorlevel 1 exit /b 1
echo Analysis, verification, figures, and report completed.
