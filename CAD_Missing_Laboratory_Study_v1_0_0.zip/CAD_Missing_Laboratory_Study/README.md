# Missing Laboratory Measurements in Coronary Artery Disease Prediction

This package evaluates whether training-time feature masking improves prediction when recorded blood-laboratory measurements are unavailable. It contains the source-data export, analysis protocol, executable code, nested cross-validation predictions, model snapshots, tables, figures, and validation records. The experiment uses the UCI Z-Alizadeh Sani dataset; it does not collect new participants or implement clinical decisions.

## Research question

How do standard training, masking-based training, and training without laboratory variables compare when all 14 blood-laboratory measurements are withheld at prediction time?

The primary comparison is the Brier-score difference between masking and standard training for logistic regression under complete laboratory absence. Negative differences favor masking. Random forest, partial laboratory absence, matched-count random missingness, and performance with complete inputs are supporting analyses.

## Package layout

| Location | Contents |
| --- | --- |
| `config/protocol.json` | Fixed analysis settings and primary comparison |
| `data/` | Source CSV, row-indexed records, variable dictionary, and validation partitions |
| `src/` | Analysis, summary, and verification scripts |
| `results/` | Archived predictions, tuning records, and numerical results |
| `models/` | Fitted models and their training/test row identifiers |
| `figures/` | Exported research figures |
| `docs/` | Protocol, provenance, limitations, and study report |
| `validation/` | Data audit, execution details, and verification results |

## Reproduction

Python 3.12 is recommended. Use Python and the dependency versions in `requirements.txt`. Run commands from the package root:

```bash
python -m pip install -r requirements.txt
python src/run_study.py --jobs 4
python src/summarize.py
python src/validate.py
python src/build_report.py
```

The fitting command runs the full nested experiment and replaces analysis outputs. To preserve the archived outputs, direct the fitting run to another directory:

```bash
python src/run_study.py --jobs 4 --output reproduced_run
python src/summarize.py --input reproduced_run
python src/validate.py --input reproduced_run
python src/build_report.py --input reproduced_run
```

Input data and configuration are always read from this package, even with a separate output directory. Set `--jobs 1` for sequential execution. Numerical results can vary slightly across numerical-library versions or platforms. Load serialized model files only from trusted sources.

Read `docs/protocol.md` before interpreting comparisons and `docs/interpretation_limits.md` before making claims about applicability. Data-source attribution and transformation details are in `docs/data_provenance.md`.

On Windows, after installing the requirements, run `run_all.bat` from a terminal. On Linux or macOS, use `bash run_all.sh`. These scripts replace the bundled results.

## Main result

The primary logistic-regression comparison did not demonstrate improvement from masking training: paired Brier difference +0.000785, with a conditional 95% interval from -0.001569 to +0.003271. This is not an equivalence finding. See `docs/study_report.pdf` for the completed analysis and `results/` for all numerical outputs.

## Integrity

`MANIFEST_SHA256.csv` lists file sizes and SHA-256 checksums. Run `python src/verify_manifest.py` to check the delivered files before rerunning the analyses; regenerated files may legitimately have different checksums.
