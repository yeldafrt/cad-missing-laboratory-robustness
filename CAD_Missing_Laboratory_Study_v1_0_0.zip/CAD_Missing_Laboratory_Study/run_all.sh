#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python src/run_study.py --jobs 4
python src/summarize.py
python src/validate.py
python src/build_report.py
